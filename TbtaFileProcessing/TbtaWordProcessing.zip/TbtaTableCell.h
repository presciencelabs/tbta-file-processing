#pragma once

#include <vector>
#include "TbtaString.h"

namespace TbtaFileProcessing
{
	class TbtaTableCell
	{
	public:

		TbtaTableCell(const TbtaString &cellText);
		~TbtaTableCell();

		//This is the entire text of the cell.
		TbtaString CellText;

		//This indicates the indices of segments contained in the cell text (e.g. contiguous underlined characters when coming from a Word document.)
		//the pair.first is the index of the segment within the CellText.  The pair.second is the length of the segment in the CellText.
		//The text for a particular segment can be retrieved by passing the segment pair to GetSegmentText(...)
		std::vector<std::pair<int, int>> SegmentIndices;

		// Gets the string representation of the segment from this cell's text for the specified segement index and length (from SegmentIndices)
		TbtaString GetSegmentText(std::pair<int, int> segmentPosition);

		operator TbtaString();
	};
}