#include "TbtaTableCell.h"

namespace TbtaFileProcessing
{
	TbtaTableCell::TbtaTableCell(const TbtaString &cellText)
		:CellText(TbtaString(cellText))
	{
	}


	TbtaTableCell::~TbtaTableCell()
	{
	}

	TbtaString TbtaFileProcessing::TbtaTableCell::GetSegmentText(std::pair<int, int> segmentPosition)
	{
		return TbtaStringSubString(CellText, segmentPosition.first, segmentPosition.second);
	}

	TbtaTableCell::operator TbtaString(){return CellText;}
}
