#include "DocxSaxHandler.h"
#include <iostream>
#include <tchar.h>
#include <unordered_set>
#include <algorithm>
#include <xercesc/Util/XMLUniDefs.hpp>
#include <regex>
#include "FileProcessingException.h"

#undef max //MFC defines a max macro that interferes with std::max, so we undef it here.

using namespace std;
using namespace xercesc;

namespace TbtaFileProcessing
{

	//table indicator
	const XMLCh tbl[] =
	{
		chLatin_t, chLatin_b, chLatin_l, chNull
	};

	//table row indicator
	const XMLCh tr[] =
	{
		chLatin_t, chLatin_r, chNull
	};

	//table cell indicator
	const XMLCh tc[] =
	{
		chLatin_t, chLatin_c, chNull
	};

	//text indicator (we ignore formatting in the word document)
	const XMLCh t[] =
	{
		chLatin_t, chNull
	};

	//text "paragraph" indicator
	const XMLCh p[] =
	{
		chLatin_p, chNull
	};

	//text "run" indicator.  All text level formatting occurs within a "run".
	const XMLCh r[] =
	{
		chLatin_r, chNull
	};

	//text underline indicator
	const XMLCh u[] =
	{
		chLatin_u, chNull
	};

	//remove a character from the celltext, adjusting current segment indices.
	static void RemoveCellTextCharacterAt(TbtaString &cellText, int index, std::vector<std::pair<int, int>> &currentCellSegments)
	{
		TbtaStringRemoveAt(cellText, index);

		for (int j = 0; j < currentCellSegments.size(); ++j)
		{
			auto segment = currentCellSegments.at(j);

			if (index >= segment.first && index < segment.first + segment.second)
			{
				segment.second = std::max(0, segment.second - 1); //adjust segment length;
			}

			if (segment.first > index)
			{
				segment.first = std::max(0, segment.first - 1); //adjust start index
			}

			currentCellSegments[j] = segment;
		}
	}

	//Apply single character replacements, and normalize multiple adjacent whitespace characters to a single space.
	static void NormalizeText(TbtaString &cellText, const std::unordered_map<wchar_t, wchar_t> &characterReplacments, std::vector<std::pair<int, int>> &currentCellSegments)
	{
		//static auto whitespace = std::unordered_set<wchar_t>({ ' ', '\t', '\r', '\n' });
		auto whitespace = std::unordered_set<wchar_t>();
		whitespace.insert(' ');
		whitespace.insert('\t');
		whitespace.insert('\r');
		whitespace.insert('\n');
		bool lastCharacterWasWhitespace = false;
		int currentLength = TbtaStringLength(cellText);

		for (int i = 0; i < currentLength; ++i)
		{
			wchar_t currentChar = TbtaStringGetAt(cellText, i);

			auto replacement = characterReplacments.find(currentChar);
			if (replacement != characterReplacments.end())
			{
				TbtaStringSetAt(cellText, i, replacement->second);
				lastCharacterWasWhitespace = false;
			}
			else if (whitespace.find(currentChar) != whitespace.end())
			{
				if (lastCharacterWasWhitespace || i == 0)
				{
					RemoveCellTextCharacterAt(cellText, i, currentCellSegments);

					--currentLength;
					--i;
				}
				else 
				{
					TbtaStringSetAt(cellText, i, ' '); //normalize all whitespace characters to a single space.
				}

				lastCharacterWasWhitespace = true;
			}
			else
			{
				lastCharacterWasWhitespace = false;
			}
		}

		//celltext should not begin or end with whitespace (begin is already taken care of in previous code block, so just need to handle end
		//for a single space)
		int iLastChar = TbtaStringLength(cellText) - 1;
		if (iLastChar > -1 && whitespace.find(TbtaStringGetAt(cellText, iLastChar)) != whitespace.end())
		{
			RemoveCellTextCharacterAt(cellText, iLastChar, currentCellSegments);
		}

		//segments should not start or end with whitespace
		//(Note, at this point in the function, we only have to worry about single space, because
		//the previous code normalizes other whitespace to single space.)
		for (int j = 0; j < currentCellSegments.size(); ++j)
		{
			auto segment = currentCellSegments.at(j);

			if (segment.second != 0)
			{
				if (whitespace.find(TbtaStringGetAt(cellText, segment.first)) != whitespace.end())
				{
					++segment.first;
					--segment.second;
				}

				if (whitespace.find(TbtaStringGetAt(cellText, segment.first + segment.second - 1)) != whitespace.end())
				{
					--segment.second;
				}

				currentCellSegments[j] = segment;
			}
			else
			{
				currentCellSegments.erase(currentCellSegments.begin() + j);
				--j;
			}
		}
	}

	//DocxSaxHandler::DocxSaxHandler(void) : DocxSaxHandler(std::unordered_map<wchar_t, wchar_t>())
	//{}
	DocxSaxHandler::DocxSaxHandler() :
		_characterReplacements(std::unordered_map<wchar_t, wchar_t>()),
		_inTable(false),
		_inCell(false),
		_inCellText(false),
		_cellHasPreviousParagraph(false),
		_isTableReady(false),
		_isNextGrammarSectionReady(false),
		_inGrammarSectionParagraph(false),
		_inPotentialGrammarSectionParagraph(false),
		_cellRunStartIndex(-1),
		_cellRunIsUnderlined(false)
	{
	}

	DocxSaxHandler::DocxSaxHandler(const std::unordered_map<wchar_t, wchar_t> &characterReplacements) :
		_characterReplacements(characterReplacements),
		_inTable(false),
		_inCell(false),
		_inCellText(false),
		_cellHasPreviousParagraph(false),
		_isTableReady(false),
		_isNextGrammarSectionReady(false),
		_inGrammarSectionParagraph(false),
		_inPotentialGrammarSectionParagraph(false),
		_cellRunStartIndex(-1),
		_cellRunIsUnderlined(false)
	{
	}

	void DocxSaxHandler::startElement(const   XMLCh* const    uri,
		const   XMLCh* const    localname,
		const   XMLCh* const    qname,
		const   Attributes&     attrs)
	{
		//TODO: xml namespace checks?

		if (xercesc::XMLString::equals(localname, tbl))
		{
			if (_inTable)
				throw FileProcessingException(FileProcessingException::NestedTablesNotSupported);

			_inTable = true;
			_isTableReady = false;
			_tableBuffer.clear();
		}

		if (_inTable)
		{
			if (_inCell && xercesc::XMLString::equals(localname, r))
			{
				_cellRunStartIndex = TbtaStringLength(_currentCellText);
			}
			else if (_cellRunStartIndex > -1 && xercesc::XMLString::equals(localname, u))
			{
				_cellRunIsUnderlined = true;
			}
			else if (_inCell && xercesc::XMLString::equals(localname, t))
			{
				if (_cellHasPreviousParagraph)
					TbtaStringAppend(_currentCellText, L" ");

				_inCellText = true;
			}
			else if (xercesc::XMLString::equals(localname, tc))
			{
				_inCell = true;
			}
			else if (xercesc::XMLString::equals(localname, tr))
			{
				_tableBuffer.push_back(TbtaTableRow());
			}
		}
		else if (xercesc::XMLString::equals(localname, p))
		{
			//match for grammer section, only at beginning of paragraph.
			_inPotentialGrammarSectionParagraph = true;
		}
	}

	void DocxSaxHandler::characters(const XMLCh* const chars, const XMLSize_t length)
	{
		if (_inPotentialGrammarSectionParagraph)
		{
			//TODO: (if thread-safe?), moving to scope where it can be reused would give (probably slight) performance boost.
			std::wregex grammarSectionPattern(_T("^\\s*Grammar\\s+Section\\s+\\d+:.*$"));

			std::wstring text(chars);

			if (std::regex_match(text, grammarSectionPattern))
			{
				TbtaStringAppendBufferLength(_nextGrammarSectionText, chars, length);
				_inGrammarSectionParagraph = true;
			}
			_inPotentialGrammarSectionParagraph = false;
		}
		else if (_inGrammarSectionParagraph)
		{
			TbtaStringAppendBufferLength(_nextGrammarSectionText, chars, length);
		}
		else if (_inCellText)
		{
			TbtaStringAppendBufferLength(_currentCellText, chars, length);
		}
	}

	void DocxSaxHandler::endElement(const XMLCh* const uri,
		const XMLCh* const localname,
		const XMLCh* const qname)
	{
		if (_inTable)
		{
			if (_inCell && xercesc::XMLString::equals(localname, t))
			{
				_inCellText = false;
			}
			else if (_inCell && xercesc::XMLString::equals(localname, p))
			{
				_cellHasPreviousParagraph = true;
			}
			else if (_inCell && xercesc::XMLString::equals(localname, r))
			{
				if (_cellRunIsUnderlined)
				{
					_currentCellSegments.push_back(std::pair<int, int>(_cellRunStartIndex, TbtaStringLength(_currentCellText) - _cellRunStartIndex));
				}
				_cellRunIsUnderlined = false;
				_cellRunStartIndex = -1;
			}
			else if (xercesc::XMLString::equals(localname, tc))
			{
				_inCell = false;
				_cellHasPreviousParagraph = false;

				NormalizeText(_currentCellText, _characterReplacements, _currentCellSegments);

				TbtaTableCell cell(_currentCellText);
				for each (std::pair<int, int> segmentSpec in _currentCellSegments)
				{
					cell.SegmentIndices.push_back(segmentSpec);
				}
				_tableBuffer.back().push_back(cell);
				TbtaStringClear(_currentCellText);
				_currentCellSegments.clear();
			}
			/*else if (xercesc::XMLString::equals(localname, tr))
			{

			}*/
			else if (xercesc::XMLString::equals(localname, tbl))
			{
				_inTable = false;
				_isTableReady = true;
			}
		}
		else if (xercesc::XMLString::equals(localname, p))
		{
			_inPotentialGrammarSectionParagraph = false;
			_isNextGrammarSectionReady = _inGrammarSectionParagraph;
			if (_isNextGrammarSectionReady)
			{
				TbtaStringClear(_currentGrammarSectionText);
				TbtaStringAppend(_currentGrammarSectionText, _nextGrammarSectionText);
				TbtaStringClear(_nextGrammarSectionText);
				ResetTableBuffers();
			}
			_inGrammarSectionParagraph = false;
		}
	}

	bool DocxSaxHandler::IsTableReady(const TbtaString &grammarSection)
	{
		if (TbtaStringIsEmpty(grammarSection) || _currentGrammarSectionText == grammarSection)
			return _isTableReady;

		return false;
	}

	bool DocxSaxHandler::IsNextGrammarSectionReady()
	{
		return _isNextGrammarSectionReady;
	}

	TbtaTable DocxSaxHandler::GetCurrentTable()
	{
		if (!_isTableReady)
			throw FileProcessingException(FileProcessingException::TableNotReady);

		return _tableBuffer;
	}

	TbtaString DocxSaxHandler::GetCurrentGrammarSection()
	{
		if (!_isNextGrammarSectionReady && TbtaStringIsEmpty(_currentGrammarSectionText))
			throw FileProcessingException(FileProcessingException::GrammarSectionNotReady);

		return _currentGrammarSectionText;
	}

	void DocxSaxHandler::ResetTableBuffers()
	{
		_tableBuffer.clear();
		TbtaStringClear(_currentCellText);

		_inTable = false;
		_inCell = false;
		_inCellText = false;
		_cellHasPreviousParagraph = false;
		_isTableReady = false;
	}

	void DocxSaxHandler::ResetGrammarSectionBuffers()
	{
		TbtaStringClear(_nextGrammarSectionText);
		_isNextGrammarSectionReady = false;
		_inGrammarSectionParagraph = false;
		_inPotentialGrammarSectionParagraph = false;
	}

	void DocxSaxHandler::fatalError(const SAXParseException& exception)
	{
		char* message = XMLString::transcode(exception.getMessage());
		wcout << "Fatal Error: " << message
			 << " at line: " << exception.getLineNumber()
			 << endl;
		XMLString::release(&message);
	}
}